# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
import pandas as pd
import re

class BrandSpider(scrapy.Spider):
	name = 'brand2'
	allowed_domains = ['https://www.thecloroxcompany.com/']
	start_urls = ['https://www.thecloroxcompany.com/en-ca/what-were-made-of/ingredients-inside/clorox-ca/clorox-bleach-clean-linen-fresh-fibregard-concentrated-55500013722/']

	def parse(self, response):
		allhtml = response.xpath("/html").extract()
		# ingredients = response.xpath("//div[@id='ingredients-about']").extract()
		# yield {'Ingredients': ingredients}

		ingredients = []
		cleaned = dict()

		for span in response.xpath("//div[@id='ingredients-about']"):
			ing = span.xpath('string(.)').get()
			ingredients.append(ing)

		cleaning = ingredients[0]
		cleaning = cleaning.strip("\n")
		cleaning = " ".join(cleaning.split(" "))



		with open("ingredients.txt", "w") as output:
			output.write(str(cleaning))
		

		


				
